package com.rivas.diego.proyectorivas.ui.fragments.main

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.rivas.diego.proyectorivas.R
import com.rivas.diego.proyectorivas.databinding.FragmentMoviesBinding
import com.rivas.diego.proyectorivas.ui.adapters.ListarMoviesPopularityAdapter
import com.rivas.diego.proyectorivas.ui.core.ManageUIStates
import com.rivas.diego.proyectorivas.ui.viewmodels.main.MoviesVM

class MoviesFragment : Fragment() {

    private lateinit var binding: FragmentMoviesBinding
    private lateinit var adapter: ListarMoviesPopularityAdapter
    private val moviesVM: MoviesVM by viewModels()
    private lateinit var manageUIStates: ManageUIStates

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMoviesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Obtener el nickname del argumento y configurar el TextView
        val nickname = arguments?.getString("USER_NICKNAME")
        binding.tvNickname.text = nickname

        // Inicializar variables, oyentes y observadores
        initVariables()
        initListeners()
        initObservers()
        initData()
    }

    private fun initData() {
        moviesVM.initData()
        Log.d("TAG", "Iniciando Datos...!")
    }

    private fun initObservers() {
        moviesVM.itemsMovies.observe(viewLifecycleOwner) {
            adapter.submitList(it)
        }

        moviesVM.uiState.observe(viewLifecycleOwner) {
            manageUIStates.invoke(it)
        }
    }

    private fun initListeners() {
        binding.ivProfilePicture.setOnClickListener {
            findNavController().navigate(R.id.action_moviesFragment_to_profileSettingsFragment)
        }
        binding.btnReturnToLogin.setOnClickListener{

            findNavController().navigate(R.id.action_moviesFragment_to_modificarFragment)
        }

    }

    private fun initVariables() {
        manageUIStates = ManageUIStates(requireActivity(), binding.lytLoading.mainLayout)
        adapter = ListarMoviesPopularityAdapter()

        binding.rvDiscover.adapter = adapter
        binding.rvDiscover.layoutManager = LinearLayoutManager(
            requireActivity(), LinearLayoutManager.HORIZONTAL, false
        )

        binding.rvRanking.adapter = adapter
        binding.rvRanking.layoutManager = LinearLayoutManager(
            requireActivity(), LinearLayoutManager.HORIZONTAL, false
        )

        binding.rvComingSoon.adapter = adapter
        binding.rvComingSoon.layoutManager = LinearLayoutManager(
            requireActivity(), LinearLayoutManager.HORIZONTAL, false
        )
    }

}

package com.rivas.diego.proyectorivas.ui.fragments.login

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.rivas.diego.proyectorivas.R
import com.rivas.diego.proyectorivas.databinding.FragmentModificarBinding
import com.rivas.diego.proyectorivas.ui.viewmodels.ModificarFragmentVM



class ModificarFragment : Fragment() {
/*

    private  lateinit var binding: FragmentModificarBinding
    //DELEGADO
    val args: ModificarFragmentArgs by  navArgs()

    private val modificarFragmentVM: ModificarFragmentVM by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=FragmentModificarBinding.bind(
            inflater.inflate(R.layout.fragment_modificar, container, false))
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.txtWelcome.text= args.name  //Pablito
        initListeners()
        initObservers()

    }

    private fun initObservers(){
        //Lo que va a cambiar
        modificarFragmentVM.cLive.observe(viewLifecycleOwner){
            binding.txtWelcome.text=it.toString()
            //DATA --ABSTRACCION DE LOS DATOS A USAR.
            //LOGICA SE ENCARGA DE CANBIAR  ACTIVAR ALGO/PEDIR LOS DATOS.
        }

    }

    private fun initListeners() {
        binding.btnContar.setOnClickListener {
            modificarFragmentVM.funcionContar()
        }

        binding.btnStop.setOnClickListener {
            modificarFragmentVM.funcionParar()
        }


    }



 */


}
package com.rivas.diego.proyectorivas.ui.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.rivas.diego.proyectorivas.R
import com.rivas.diego.proyectorivas.databinding.ActivityMainBinding
import com.rivas.diego.proyectorivas.ui.fragments.login.LoginFragment
import com.rivas.diego.proyectorivas.ui.fragments.main.MoviesFragment


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val splash = installSplashScreen()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val nickname = intent.getStringExtra("USER_NICKNAME")
        val moviesFragment = MoviesFragment()
        val bundle = Bundle()
        bundle.putString("USER_NICKNAME", nickname)
        moviesFragment.arguments = bundle

        supportFragmentManager.beginTransaction()
            .replace(R.id.containerFragments, moviesFragment)
            .commit()


        /*

        splash.setKeepOnScreenCondition { false }

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, LoginFragment())
                .commit()
        }

         */


    }
}
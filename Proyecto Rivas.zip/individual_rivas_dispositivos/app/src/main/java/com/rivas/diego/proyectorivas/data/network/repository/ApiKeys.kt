package com.rivas.diego.proyectorivas.data.network.repository

object ApiKeys {

    const val TS_MARVEL = 0
    const val HASH_MARVEL = ""
    const val PUBLIC_KEY_MARVEL = ""
}


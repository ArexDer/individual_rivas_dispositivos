package com.rivas.diego.proyectorivas.ui.viewmodels.login

import android.content.Context
import android.util.Log
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.rivas.diego.proyectorivas.ui.core.UIStates
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class LoginFragmentVM : ViewModel() {

    private var auth: FirebaseAuth? = null

    var uiState = MutableLiveData<UIStates>()

    fun authWhitFireBase(email: String, password: String, auth: FirebaseAuth, context: FragmentActivity) {
        viewModelScope.launch {
            uiState.postValue(UIStates.Loading(true))
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(context) { task ->
                    if (task.isSuccessful) {
                        uiState.postValue(UIStates.Success(true))
                    } else {
                        Log.w("TAG", "Error al entrar con correo", task.exception)
                        uiState.postValue(UIStates.Error("Credenciales Incorrectas, Seguro las pusiste bien"))
                    }
                }
            delay(500)
            uiState.postValue(UIStates.Loading(false))
        }
    }
}
